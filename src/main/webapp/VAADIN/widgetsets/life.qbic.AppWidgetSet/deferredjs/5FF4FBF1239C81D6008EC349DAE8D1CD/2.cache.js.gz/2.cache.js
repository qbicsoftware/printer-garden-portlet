$wnd.life_qbic_AppWidgetSet.runAsyncCallback2('kfb(1667,1,X6d);_.vc=function flc(){X4b((!Q4b&&(Q4b=new a5b),Q4b),this.a.d)};r0d(Th)(2);\n//# sourceURL=life.qbic.AppWidgetSet-2.js\n')
